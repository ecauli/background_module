# Background
module Background
  
  
end

ActionView::Base.send :include, FundoHelper
  
  #require File.join(File.dirname(__FILE__), "lib", "background")

#ActionView::Base.send :include, FundoHelper